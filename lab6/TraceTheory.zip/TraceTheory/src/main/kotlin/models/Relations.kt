package models

data class Relations(val relations: MutableMap<Char, MutableSet<Char>>)
