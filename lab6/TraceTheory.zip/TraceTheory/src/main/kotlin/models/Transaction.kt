package main.kotlin.models

data class Transaction(val name: Char, val formula: String)
